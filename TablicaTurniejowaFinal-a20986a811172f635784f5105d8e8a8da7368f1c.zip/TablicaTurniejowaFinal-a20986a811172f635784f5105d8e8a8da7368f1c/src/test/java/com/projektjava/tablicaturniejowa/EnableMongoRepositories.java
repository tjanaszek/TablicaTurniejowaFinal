package com.projektjava.tablicaturniejowa;

public @interface EnableMongoRepositories {
}
