package com.projektjava.tablicaturniejowa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablicaTurniejowaApplicationTests {

    @Test
    void contextLoads() {
    }

}
